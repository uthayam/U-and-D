package com.groupD.corepackage;

/**
 *
 * @author fayimora
 */
public class ComputerPlayer
{
    static int count=0;
    private final String computerName = "ComputerPLayer"+(++count);
    
}
