/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.groupD.corepackage;

/**
 * @author fayimora
 */
public class HumanPlayer extends Player 
{
    public HumanPlayer(String name, Token token)
    {
        super(name,token);
    }
    
    public void moveToken(Cell from, Cell to)
    {
        //TODO
    }
    
}
