/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.groupD.uipackage.cli;

/**
 *
 * @author fayimora
 */
public class Main {
    
}
